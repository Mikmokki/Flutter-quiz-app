import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../../../lib/screens/util/screen_wrapper.dart';

void main() {
  testWidgets('ScreenWrapper displays AppBar and body widget',
      (WidgetTester tester) async {
    const widgetUnderTest = Text('Test Widget');
    await tester.pumpWidget(
      MaterialApp(
        home: ScreenWrapper(widgetUnderTest),
      ),
    );
    expect(find.byType(AppBar), findsOneWidget);

    expect(find.byWidget(widgetUnderTest), findsOneWidget);
  });
}
