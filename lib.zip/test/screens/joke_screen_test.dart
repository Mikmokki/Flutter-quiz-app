import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../../lib/screens/joke_screen.dart';
import '../../lib/jokes/jokes.dart';
import '../../lib/screens/joke_screen.dart';

void main() {
  testWidgets('JokeScreen has the right stuff and exits',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: JokeScreen(),
      ),
    );
    expect(find.text('Back'), findsOneWidget);

    await tester.tap(find.text('Back'));
    await tester.pumpAndSettle();
    expect(find.byType(JokeScreen), findsNothing);
  });
}
