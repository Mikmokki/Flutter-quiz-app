import 'package:test/test.dart';
import '../../lib/jokes/jokes.dart';

void main() {
  test('Calling fun() returns "Testing is fun".', () async {
    expect(JokeRepository.randomJoke().question,
        isNot(equals("What's orange and sounds like a parrot?")));
  });
}
